//
//  YouAreAwesomeApp.swift
//  YouAreAwesome
//
//  Created by 1 on 10/20/23.
//

import SwiftUI

@main
struct YouAreAwesomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
